1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/2e59f4238886288d.js"],"AuthProvider"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/2e59f4238886288d.js"],""]
10:I[68027,[],"default"]
:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
5:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      8:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"P":null,"b":"a-I7JEY3JjJc78c4aaeM5","c":["","san-pham"],"q":"","i":false,"f":[[["",{"children":["(main)",{"children":["san-pham",{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/dee56bed382e44f7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2e59f4238886288d.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{"children":"$undefined"}],["$","body",null,{"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$5"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L6",null,{"src":"./script-alt.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"./product-script.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"/script-login.js","strategy":"lazyOnload"}]]}]]}]]}],{"children":[["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3c46c67f24ea5105.js","async":true,"nonce":"$undefined"}]],["$L7",["$","main",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$8"}],"$L9","$La","$Lb"],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],"$Lc"]]}],{"children":["$Ld",{"children":["$Le",{},null,false,false]},null,false,false]},null,false,false]},null,false,false],"$Lf",false]],"m":"$undefined","G":["$10",[]],"S":true}
11:I[22016,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js","/_next/static/chunks/a8722805a7e8d032.js"],""]
13:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
14:"$Sreact.suspense"
16:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ViewportBoundary"]
18:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"MetadataBoundary"]
9:["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}]
a:["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}]
b:["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]
c:["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"container footer-container","children":[["$","div",null,{"className":"footer-col logo-col","children":[["$","h2",null,{"className":"footer-logo","children":["MANH ",["$","span",null,{"children":"PHÁT"}]]}],["$","p",null,{"className":"footer-desc","children":"Manh Phát được thành lập với mong muốn tạo ra một môi trường làm việc chuyên nghiệp, và cung cấp giải pháp tối ưu trong lĩnh vực camera giám sát, năng lượng mặt trời, và điện cơ."}],["$","div",null,{"className":"footer-contact","children":[["$","p",null,{"children":[["$","span",null,{"children":"Location"}]," 145, DT741, Phường Phước Bình, Đồng Nai"]}],["$","p",null,{"children":[["$","span",null,{"children":"Phone"}]," 0328.76.2676"]}],["$","p",null,{"children":[["$","span",null,{"children":"Email"}]," hitlong.dinho.89@gmail.com"]}]]}]]}],["$","div",null,{"className":"footer-col map-col","children":[["$","h3",null,{"children":"CHỈ ĐƯỜNG"}],["$","div",null,{"className":"map-wrapper","children":["$","iframe",null,{"src":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.610934259323!2d106.7894596148005!3d10.83445779228892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528e1e6396e13%3A0x74b745b6f0e1c8c!2sCTY%20TNHH%20C%C6%A0%20%C4%90I%E1%BB%86N%20MANH%20PH%C3%81T!5e0!3m2!1svi!2s!4v1710000000000","width":"100%","height":300,"style":{"border":0},"loading":"lazy"}]}]]}],["$","div",null,{"className":"footer-col social-col","children":[["$","h3",null,{"children":"LIÊN KẾT"}],["$","ul",null,{"className":"social-links","children":[["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Facebook kỹ thuật"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Facebook kinh doanh"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Zalo kỹ thuật"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Zalo kinh doanh"}]}]]}]]}]]}],["$","div",null,{"className":"footer-bottom","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2026 Tấn Long. Đã đăng ký bản quyền. Design with Tấn Long & Cà Phê"}]}]}]]}]
d:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
e:["$","$1","c",{"children":["$L12",[["$","script","script-0",{"src":"/_next/static/chunks/a8722805a7e8d032.js","async":true,"nonce":"$undefined"}]],["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]]}]
f:["$","$1","h",{"children":[null,["$","$L16",null,{"children":"$L17"}],["$","div",null,{"hidden":true,"children":["$","$L18",null,{"children":["$","$14",null,{"name":"Next.Metadata","children":"$L19"}]}]}],null]}]
17:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1a:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"IconMark"]
15:null
19:[["$","title","0",{"children":"Camera giám sát - năng lượng mặt trời"}],["$","meta","1",{"name":"description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","2",{"name":"keywords","content":"camera giám sát,năng lượng mặt trời,thi công điện nước,pccc,camera giam sat,nang luong mat troi,thi cong dien nuoc,thiết bị pccc,thiet bi pccc,bình chữa cháy,binh chua chay,bảo hộ lao động,bao ho lao dong"}],["$","link","3",{"rel":"canonical","href":"https://tanlong.work.gd"}],["$","meta","4",{"property":"og:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","5",{"property":"og:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","6",{"property":"og:url","content":"https://tanlong.work.gd"}],["$","meta","7",{"property":"og:site_name","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","8",{"property":"og:locale","content":"vi_VN"}],["$","meta","9",{"property":"og:country_name","content":"Việt Nam"}],["$","meta","10",{"property":"og:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],["$","meta","12",{"property":"og:image:height","content":"630"}],["$","meta","13",{"property":"og:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","14",{"property":"og:email","content":"hitlong.dinho.89@gmail.com"}],["$","meta","15",{"property":"og:phone_number","content":"0328732676"}],["$","meta","16",{"property":"og:type","content":"website"}],["$","meta","17",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","18",{"name":"twitter:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","19",{"name":"twitter:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","20",{"name":"twitter:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","21",{"name":"twitter:image:width","content":"800"}],["$","meta","22",{"name":"twitter:image:height","content":"630"}],["$","meta","23",{"name":"twitter:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","link","24",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","25",{"rel":"icon","href":"/favicon.ico?favicon.b838974e.ico","sizes":"32x31","type":"image/x-icon"}],["$","link","26",{"rel":"icon","href":"/logo-manh-phat-van-ban.png"}],["$","link","27",{"rel":"apple-touch-icon","href":"/favicon.ico"}],["$","$L1a","28",{}]]
1b:I[88589,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
7:[["$","div",null,{"className":"topbar","children":["$","div",null,{"className":"topbar-container","children":[["$","div",null,{"className":"topbar-left","children":[["$","div",null,{"className":"dropdown","id":"lang-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tiếng Việt ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L11",null,{"href":"#","children":"Tiếng Việt"}],["$","$L11",null,{"href":"#","children":"English"}]]}]]}],["$","div",null,{"className":"dropdown","id":"account-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tài khoản của bạn ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L11",null,{"href":"/login","children":"Đăng nhập"}],["$","hr",null,{}],["$","$L11",null,{"href":"/register","children":"Đăng ký miễn phí"}],["$","hr",null,{}]]}]]}]]}],["$","div",null,{"className":"topbar-right","children":[["$","$L11",null,{"href":"/product-detail","className":"highlight","children":"Mã giảm giá"}],["$","$L11",null,{"href":"/guide","children":"Hướng dẫn"}],["$","a",null,{"href":"tel:0328732676","className":"hotline","children":"Hotline: 0328.73.2676"}]]}]]}]}],["$","header",null,{"className":"main-header","children":["$","div",null,{"className":"container","children":[["$","$L11",null,{"href":"/","className":"logo","children":["$","img",null,{"src":"https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","alt":"Muamau","height":44}]}],["$","$L1b",null,{"subCategories":[{"id":1,"categoryName":"Ip","slugSub":"nguyen-tan-long-1.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":2,"categoryName":"Thân","slugSub":"nguyen-tan-long-2.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":3,"categoryName":"Quấn motor","slugSub":"nguyen-tan-long-3.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":4,"categoryName":"Thiết kế Website","slugSub":"nguyen-tan-long-4.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":5,"categoryName":"Thi công PCCC","slugSub":"nguyen-tan-long-5.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":6,"categoryName":"Điện dân dụng","slugSub":"nguyen-tan-long-6.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":7,"categoryName":"Xưởng & đất lớn","slugSub":"nguyen-tan-long-7.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":8,"categoryName":"Nhà dân & đất nền","slugSub":"nguyen-tan-long-8.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":11,"categoryName":"Thiết kế phần mềm","slugSub":"nguyen-tan-long-9.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":12,"categoryName":"Đất dự án","slugSub":"nguyen-tan-long-10.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":13,"categoryName":"Sữa chữa camera","slugSub":"nguyen-tan-long-11.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":14,"categoryName":"Sữa chũa laptop pc","slugSub":"nguyen-tan-long-12.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":15,"categoryName":"Nạp bình chữa cháy","slugSub":"nguyen-tan-long-13.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":16,"categoryName":"Bình chữa cháy bột","slugSub":"nguyen-tan-long-14.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":17,"categoryName":"Bình chữa cháy khí","slugSub":"nguyen-tan-long-15.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":18,"categoryName":"Bình chữa cháy gốc nước","slugSub":"nguyen-tan-long-16.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":19,"categoryName":"Vật tư PCCC","slugSub":"nguyen-tan-long-17.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":20,"categoryName":"SP Mạnh Phát","slugSub":"nguyen-tan-long-18.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"}]}],"$L1c"]}]}]]
1d:I[5903,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
1c:["$","$L1d",null,{}]
1e:I[5500,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js","/_next/static/chunks/a8722805a7e8d032.js"],"Image"]
12:[["$","span",null,{"children":"Tất cả sản phẩm"}],["$","div",null,{"className":"suggestion-grid","children":[["$","div","0036a669-8ae2-4da0-8122-f047f193ca2c",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/thiet-ke-website-theo-yeu-cau.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/481265871-3179784195497119-3536643745973864873-n-nguyen-tan-long-1774142057153.jpg","alt":"Thiết kế Website theo yêu cầu","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Thiết kế Website theo yêu cầu"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["8.000.000"," ₫"]}],["$","span",null,{"className":"sold","children":[93," sản phẩm"]}]]}]]}]}],["$","div","076fbe1b-d2ae-4619-8f2e-b5b9b64a398c",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/ton-kliplock-1000.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/ton-kliplock-at-nguyen-tan-long-1773218896199.webp","alt":"Tôn kliplock 1000","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Tôn kliplock 1000"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["110.000"," ₫"]}],["$","span",null,{"className":"sold","children":[39," sản phẩm"]}]]}]]}]}],["$","div","12ed1330-6178-4c7b-9a59-25bcfc2a9f40",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/den-nang-luong-mat-troi.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/den-nang-luong-mat-troi-binh-duong-nguyen-tan-long-1773712454044.webp","alt":"Đèn năng lượng mặt trời","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Đèn năng lượng mặt trời"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["1.350.000"," ₫"]}],["$","span",null,{"className":"sold","children":[8," sản phẩm"]}]]}]]}]}],["$","div","153d868f-b2cf-4cd6-939a-dae7dd9b07e8",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/test-them-pham.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/dang-pk1-nguyen-tan-long-1776653366343.jpg","alt":"Test thêm phẩm ","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Test thêm phẩm "}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["945.000"," ₫"]}],["$","span",null,{"className":"sold","children":[5," sản phẩm"]}]]}]]}]}],["$","div","318d4f14-a56d-4313-98d7-fa6a8d9106a2",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/cho-thue-xuong.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/xuong-thue-nguyen-tan-long-1773219281651.jpg","alt":"Cho Thuê xưởng","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Cho Thuê xưởng"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["135.000"," ₫"]}],["$","span",null,{"className":"sold","children":[39," sản phẩm"]}]]}]]}]}],["$","div","548f8fc1-e57d-44c1-96b5-f815d0c95d82",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/camera-tplink-topo-c222.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/camera-ip-wifi-360-hong-ngoai-4mp-tp-link-tapo-c222-nguyen-tan-long-1773218586727.webp","alt":"Camera TPLink-Tapo C200","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Camera TPLink-Tapo C200"}],["$","div",null,{"className":"price","children":["$L1f","$L20"]}]]}]}],"$L21","$L22","$L23","$L24","$L25","$L26","$L27","$L28","$L29","$L2a"]}]]
1f:["$","span",null,{"className":"price-new","children":["600.000"," ₫"]}]
20:["$","span",null,{"className":"sold","children":[68," sản phẩm"]}]
21:["$","div","569f9646-4b12-45e3-9992-aab470566660",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/camera-h8c.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/cs-h8c-2k-nguyen-tan-long-1773799215546.webp","alt":"Camera H8C","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Camera H8C"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["749.999"," ₫"]}],["$","span",null,{"className":"sold","children":[200," sản phẩm"]}]]}]]}]}]
22:["$","div","59db9dd0-185d-4e0f-9dfb-3211d9672f65",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/them-san-pham-co-youtbe.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/loi-youtube-nguyen-tan-long-1776654254255.png","alt":"Thêm sản phẩm có youtbe","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Thêm sản phẩm có youtbe"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["100.100"," ₫"]}],["$","span",null,{"className":"sold","children":[5," sản phẩm"]}]]}]]}]}]
23:["$","div","5bbec80c-7815-43e4-88f2-7f14aa82e317",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/binh-chua-chay-bot.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/ba-nh-cha-a-cha-y-8kg-nguyen-tan-long-1774944211997.webp","alt":"Bình chữa cháy bột","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Bình chữa cháy bột"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["1.459"," ₫"]}],["$","span",null,{"className":"sold","children":[31," sản phẩm"]}]]}]]}]}]
24:["$","div","636accc5-1703-420b-a2b6-78f0e7305ab7",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/binh-chua-chay-goc-nuoc.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/binh-chua-chay-goc-nuoc-binh-duong-nguyen-tan-long-1773712642497.webp","alt":"Bình chữa cháy gốc nước","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Bình chữa cháy gốc nước"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["800.000"," ₫"]}],["$","span",null,{"className":"sold","children":[8," sản phẩm"]}]]}]]}]}]
25:["$","div","816a725b-7805-4646-affb-117f0599e9e3",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/camera-tplink-tapo-c520w.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/camera-ngoai-troi-wifi-4mp-tp-link-c520ws-nguyen-tan-long-1773218732051.webp","alt":"Camera TPLink-Tapo C520W","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Camera TPLink-Tapo C520W"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["8.000.000"," ₫"]}],["$","span",null,{"className":"sold","children":[39," sản phẩm"]}]]}]]}]}]
26:["$","div","8e262eab-9afa-4fcc-98ef-9606954f5514",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/ton-seamlock-1000.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/file-nguyen-tan-long-1773219017961.webp","alt":"Tôn Seamlock 1000","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Tôn Seamlock 1000"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["109.999"," ₫"]}],["$","span",null,{"className":"sold","children":[39," sản phẩm"]}]]}]]}]}]
27:["$","div","94122557-3533-4b2a-82d0-7eb3eb69515d",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/xa-go-z-ma-kem.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/xa-go-at-nguyen-tan-long-1773798770582.webp","alt":"Xà gồ Z mạ kẽm","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Xà gồ Z mạ kẽm"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["93.000"," ₫"]}],["$","span",null,{"className":"sold","children":[3000," sản phẩm"]}]]}]]}]}]
28:["$","div","e444851a-f20c-463e-98d5-571f3f0e6449",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/xa-go-c.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/xa-go-c-ma-kem-at-nguyen-tan-long-1773798956502.webp","alt":"Xà gồ C","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Xà gồ C"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["93.000"," ₫"]}],["$","span",null,{"className":"sold","children":[3000," sản phẩm"]}]]}]]}]}]
29:["$","div","e6c761e2-698d-4289-a27d-be6a0ef244fe",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/binh-chua-chay-co2.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/ba-nh-cha-a-cha-y-co2-nguyen-tan-long-1774942790411.webp","alt":"Bình chữa cháy CO2","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Bình chữa cháy CO2"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["235.000"," ₫"]}],["$","span",null,{"className":"sold","children":[35," sản phẩm"]}]]}]]}]}]
2a:["$","div","fcceb819-cb7d-499b-a270-66e1e360c595",{"className":"suggestion-card","children":["$","$L11",null,{"href":"/ton-5-song.html","className":"product-link","children":["$undefined",["$","$L1e",null,{"src":"/mediaasset/ton-5-song-1024x680-nguyen-tan-long-1773712932880.webp","alt":"Tôn 5 sóng","width":100,"height":90}],["$","div",null,{"className":"badges","children":[["$","span",null,{"className":"badge-discount","children":"Khuyến mãi"}],["$","span",null,{"className":"badge-official","children":"Cửa hàng"}]]}],["$","h3",null,{"children":"Tôn 5 sóng"}],["$","div",null,{"className":"price","children":[["$","span",null,{"className":"price-new","children":["102.000"," ₫"]}],["$","span",null,{"className":"sold","children":[3000," sản phẩm"]}]]}]]}]}]
