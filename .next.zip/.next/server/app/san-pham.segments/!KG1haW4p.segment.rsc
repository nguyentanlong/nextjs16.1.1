1:"$Sreact.fragment"
2:I[22016,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js","/_next/static/chunks/a8722805a7e8d032.js"],""]
3:I[88589,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
7:I[5903,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
8:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
9:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3c46c67f24ea5105.js","async":true}]],[[["$","div",null,{"className":"topbar","children":["$","div",null,{"className":"topbar-container","children":[["$","div",null,{"className":"topbar-left","children":[["$","div",null,{"className":"dropdown","id":"lang-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tiếng Việt ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L2",null,{"href":"#","children":"Tiếng Việt"}],["$","$L2",null,{"href":"#","children":"English"}]]}]]}],["$","div",null,{"className":"dropdown","id":"account-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tài khoản của bạn ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L2",null,{"href":"/login","children":"Đăng nhập"}],["$","hr",null,{}],["$","$L2",null,{"href":"/register","children":"Đăng ký miễn phí"}],["$","hr",null,{}]]}]]}]]}],["$","div",null,{"className":"topbar-right","children":[["$","$L2",null,{"href":"/product-detail","className":"highlight","children":"Mã giảm giá"}],["$","$L2",null,{"href":"/guide","children":"Hướng dẫn"}],["$","a",null,{"href":"tel:0328732676","className":"hotline","children":"Hotline: 0328.73.2676"}]]}]]}]}],["$","header",null,{"className":"main-header","children":["$","div",null,{"className":"container","children":[["$","$L2",null,{"href":"/","className":"logo","children":["$","img",null,{"src":"https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","alt":"Muamau","height":44}]}],["$","$L3",null,{"subCategories":[{"id":1,"categoryName":"Ip","slugSub":"nguyen-tan-long-1.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":2,"categoryName":"Thân","slugSub":"nguyen-tan-long-2.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":3,"categoryName":"Quấn motor","slugSub":"nguyen-tan-long-3.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":4,"categoryName":"Thiết kế Website","slugSub":"nguyen-tan-long-4.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":5,"categoryName":"Thi công PCCC","slugSub":"nguyen-tan-long-5.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":6,"categoryName":"Điện dân dụng","slugSub":"nguyen-tan-long-6.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":7,"categoryName":"Xưởng & đất lớn","slugSub":"nguyen-tan-long-7.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":8,"categoryName":"Nhà dân & đất nền","slugSub":"nguyen-tan-long-8.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":11,"categoryName":"Thiết kế phần mềm","slugSub":"nguyen-tan-long-9.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":12,"categoryName":"Đất dự án","slugSub":"nguyen-tan-long-10.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":13,"categoryName":"Sữa chữa camera","slugSub":"nguyen-tan-long-11.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":14,"categoryName":"Sữa chũa laptop pc","slugSub":"nguyen-tan-long-12.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":15,"categoryName":"Nạp bình chữa cháy","slugSub":"nguyen-tan-long-13.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":16,"categoryName":"Bình chữa cháy bột","slugSub":"nguyen-tan-long-14.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":17,"categoryName":"Bình chữa cháy khí","slugSub":"nguyen-tan-long-15.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":18,"categoryName":"Bình chữa cháy gốc nước","slugSub":"nguyen-tan-long-16.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":19,"categoryName":"Vật tư PCCC","slugSub":"nguyen-tan-long-17.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":20,"categoryName":"SP Mạnh Phát","slugSub":"nguyen-tan-long-18.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"}]}],"$L4"]}]}]],"$L5","$L6"]]}],"loading":null,"isPartial":false}
4:["$","$L7",null,{}]
a:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      5:["$","main",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}],"notFound":[[["$","style",null,{"children":"$a"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]]}]}]
6:["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"container footer-container","children":[["$","div",null,{"className":"footer-col logo-col","children":[["$","h2",null,{"className":"footer-logo","children":["MANH ",["$","span",null,{"children":"PHÁT"}]]}],["$","p",null,{"className":"footer-desc","children":"Manh Phát được thành lập với mong muốn tạo ra một môi trường làm việc chuyên nghiệp, và cung cấp giải pháp tối ưu trong lĩnh vực camera giám sát, năng lượng mặt trời, và điện cơ."}],["$","div",null,{"className":"footer-contact","children":[["$","p",null,{"children":[["$","span",null,{"children":"Location"}]," 145, DT741, Phường Phước Bình, Đồng Nai"]}],["$","p",null,{"children":[["$","span",null,{"children":"Phone"}]," 0328.76.2676"]}],["$","p",null,{"children":[["$","span",null,{"children":"Email"}]," hitlong.dinho.89@gmail.com"]}]]}]]}],["$","div",null,{"className":"footer-col map-col","children":[["$","h3",null,{"children":"CHỈ ĐƯỜNG"}],["$","div",null,{"className":"map-wrapper","children":["$","iframe",null,{"src":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.610934259323!2d106.7894596148005!3d10.83445779228892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528e1e6396e13%3A0x74b745b6f0e1c8c!2sCTY%20TNHH%20C%C6%A0%20%C4%90I%E1%BB%86N%20MANH%20PH%C3%81T!5e0!3m2!1svi!2s!4v1710000000000","width":"100%","height":300,"style":{"border":0},"loading":"lazy"}]}]]}],["$","div",null,{"className":"footer-col social-col","children":[["$","h3",null,{"children":"LIÊN KẾT"}],["$","ul",null,{"className":"social-links","children":[["$","li",null,{"children":["$","$L2",null,{"href":"tel:+84328732676","children":"Facebook kỹ thuật"}]}],["$","li",null,{"children":["$","$L2",null,{"href":"tel:+84328732676","children":"Facebook kinh doanh"}]}],["$","li",null,{"children":["$","$L2",null,{"href":"tel:+84328732676","children":"Zalo kỹ thuật"}]}],["$","li",null,{"children":["$","$L2",null,{"href":"tel:+84328732676","children":"Zalo kinh doanh"}]}]]}]]}]]}],["$","div",null,{"className":"footer-bottom","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2026 Tấn Long. Đã đăng ký bản quyền. Design with Tấn Long & Cà Phê"}]}]}]]}]
