var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/subcategories/route.js")
R.c("server/chunks/[root-of-the-server]__318d62b0._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_subcategories_route_actions_f21d63c3.js")
R.m(27258)
module.exports=R.m(27258).exports
