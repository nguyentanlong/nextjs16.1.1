var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__8aedf031._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_refresh_route_actions_eaf775f4.js")
R.m(31913)
module.exports=R.m(31913).exports
