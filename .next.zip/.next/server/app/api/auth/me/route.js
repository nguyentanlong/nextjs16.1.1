var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__0666f6aa._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_97ac7615.js")
R.m(93025)
module.exports=R.m(93025).exports
