1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"AuthProvider"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
10:I[68027,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
:HL["/_next/static/chunks/2cb20408bc896f7e.css","style"]
6:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"P":null,"b":"IB0L2m1cykyh4u1kUrVtw","c":["","_not-found"],"q":"","i":false,"f":[[["",{"children":["/_not-found",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2cb20408bc896f7e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/d01fb2d5fb7718e4.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{"children":"$undefined"}],["$","body",null,{"children":[["$","$L2",null,{"children":["$L3",["$","main",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$6"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"container footer-container","children":[["$","div",null,{"className":"footer-col logo-col","children":[["$","h2",null,{"className":"footer-logo","children":["MANH ",["$","span",null,{"children":"PHÁT"}]]}],["$","p",null,{"className":"footer-desc","children":"Manh Phát được thành lập với mong muốn tạo ra một môi trường làm việc chuyên nghiệp, và cung cấp giải pháp tối ưu trong lĩnh vực camera giám sát, năng lượng mặt trời, và điện cơ."}],["$","div",null,{"className":"footer-contact","children":[["$","p",null,{"children":[["$","span",null,{"children":"Location"}]," 51, ĐT744, kp Phú Thọ, p Phú An, HCM"]}],["$","p",null,{"children":[["$","span",null,{"children":"Phone"}]," Phone: 0934 181 151"]}],["$","p",null,{"children":[["$","span",null,{"children":"Email"}]," congtytnhcodienmanhphat@gmail.com"]}]]}]]}],["$","div",null,{"className":"footer-col map-col","children":[["$","h3",null,{"children":"CHỈ ĐƯỜNG"}],["$","div",null,{"className":"map-wrapper","children":["$","iframe",null,{"src":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.610934259323!2d106.7894596148005!3d10.83445779228892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528e1e6396e13%3A0x74b745b6f0e1c8c!2sCTY%20TNHH%20C%C6%A0%20%C4%90I%E1%BB%86N%20MANH%20PH%C3%81T!5e0!3m2!1svi!2s!4v1710000000000","width":"100%","height":300,"style":{"border":0},"loading":"lazy"}]}]]}],"$L7"]}],"$L8"]}]]}],"$L9","$La","$Lb","$Lc"]}]]}]]}],{"children":["$Ld",{"children":["$Le",{},null,false,false]},null,false,false]},null,false,false],"$Lf",false]],"m":"$undefined","G":["$10","$undefined"],"S":true}
11:I[79520,["/_next/static/chunks/d01fb2d5fb7718e4.js"],""]
13:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
14:"$Sreact.suspense"
16:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ViewportBoundary"]
18:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"MetadataBoundary"]
7:["$","div",null,{"className":"footer-col social-col","children":[["$","h3",null,{"children":"LIÊN KẾT"}],["$","ul",null,{"className":"social-links","children":[["$","li",null,{"children":["$","a",null,{"href":"#","children":"Facebook kỹ thuật"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Facebook kinh doanh"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Zalo kỹ thuật"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Zalo kinh doanh"}]}]]}]]}]
8:["$","div",null,{"className":"footer-bottom","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2025 Manh Phát. Đã đăng ký bản quyền. Design with Love by Đệ tử & Sư phụ"}]}]}]
9:["$","$L11",null,{"src":"/script.js","strategy":"afterInteractive"}]
a:["$","$L11",null,{"src":"./script-alt.js","strategy":"afterInteractive"}]
b:["$","$L11",null,{"src":"./product-script.js","strategy":"afterInteractive"}]
c:["$","$L11",null,{"src":"/script-login.js","strategy":"afterInteractive"}]
d:["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
12:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      e:["$","$1","c",{"children":[[["$","style",null,{"children":"$12"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],null,["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]]}]
f:["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L16",null,{"children":"$L17"}],["$","div",null,{"hidden":true,"children":["$","$L18",null,{"children":["$","$14",null,{"name":"Next.Metadata","children":"$L19"}]}]}],null]}]
17:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1a:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"IconMark"]
15:null
19:[["$","title","0",{"children":"Camera giám sát - năng lượng mặt trời"}],["$","meta","1",{"name":"description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","2",{"name":"keywords","content":"camera giám sat,năng lượng mặt trời,thi công điện nước,pccc"}],["$","meta","3",{"property":"og:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","4",{"property":"og:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","5",{"property":"og:url","content":"https://tanlong.cameramattroi.com"}],["$","meta","6",{"property":"og:site_name","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","7",{"property":"og:image","content":"https://tanong.cameramattroi.com/favicon.ico"}],["$","meta","8",{"property":"og:image:width","content":"1200"}],["$","meta","9",{"property":"og:image:height","content":"630"}],["$","meta","10",{"property":"og:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","11",{"property":"og:type","content":"website"}],["$","meta","12",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","13",{"name":"twitter:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","14",{"name":"twitter:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","15",{"name":"twitter:image","content":"https://tanong.cameramattroi.com/og-cover.jpg"}],["$","link","16",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","17",{"rel":"icon","href":"/favicon.ico?favicon.b838974e.ico","sizes":"32x31","type":"image/x-icon"}],["$","link","18",{"rel":"icon","href":"/favicon.ico"}],["$","link","19",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png"}],["$","$L1a","20",{}]]
1b:I[22016,["/_next/static/chunks/d01fb2d5fb7718e4.js"],""]
1c:I[88589,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"default"]
1d:I[5903,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"default"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
3:[["$","div",null,{"className":"topbar","children":["$","div",null,{"className":"topbar-container","children":[["$","div",null,{"className":"topbar-left","children":[["$","div",null,{"className":"dropdown","id":"lang-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tiếng Việt ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L1b",null,{"href":"#","children":"Tiếng Việt"}],["$","$L1b",null,{"href":"#","children":"English"}]]}]]}],["$","div",null,{"className":"dropdown","id":"account-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tài khoản của bạn ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L1b",null,{"href":"/login","children":"Đăng nhập"}],["$","hr",null,{}],["$","$L1b",null,{"href":"/register","children":"Đăng ký miễn phí"}],["$","hr",null,{}]]}]]}]]}],["$","div",null,{"className":"topbar-right","children":[["$","$L1b",null,{"href":"/product-detail","className":"highlight","children":"Mã giảm giá"}],["$","$L1b",null,{"href":"/guide","children":"Hướng dẫn"}],["$","a",null,{"href":"tel:0328732676","className":"hotline","children":"Hotline: 0328.73.2676"}]]}]]}]}],["$","header",null,{"className":"main-header","children":["$","div",null,{"className":"container","children":[["$","$L1b",null,{"href":"/","className":"logo","children":["$","img",null,{"src":"https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","alt":"Muamau","height":44}]}],["$","$L1c",null,{"subCategories":[]}],["$","$L1d",null,{}]]}]}]]
