1:"$Sreact.fragment"
3:I[5500,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js","/_next/static/chunks/a8722805a7e8d032.js"],"Image"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
5:"$Sreact.suspense"
2:T5b7,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
          img{width: 100%}
      0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[[["$","style",null,{"children":"$2"}],["$","header",null,{"children":[["$","h1",null,{"children":"Nguyên Tấn Long"}],["$","p",null,{"children":"Sinh ngày 09/09/1989"}]]}],["$","section",null,{"children":[["$","h2",null,{"children":"Về Tôi"}],["$","p",null,{"children":["Tôi là ",["$","span",null,{"className":"highlight","children":"Nguyên Tấn Long"}],", sinh ngày 09/09/1989. Với niềm đam mê học hỏi và khát vọng phát triển, tôi luôn hướng đến việc tạo ra giá trị bền vững cho cộng đồng và xã hội."]}],["$","$L3",null,{"src":"/public/ANH-DD.webp","alt":"Nguyen-Tan-Long","width":578,"height":600}],["$","p",null,{"children":"Trang web này được xây dựng nhằm chia sẻ hành trình, kinh nghiệm và những dự án mà tôi đã và đang thực hiện. Tôi tin rằng mỗi bước đi đều mang lại bài học quý giá, và tôi muốn lan tỏa tinh thần tích cực đó đến mọi người."}],["$","p",null,{"children":"Nếu bạn quan tâm, hãy kết nối để cùng nhau hợp tác và phát triển."}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[["$","script","script-0",{"src":"/_next/static/chunks/a8722805a7e8d032.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"loading":null,"isPartial":false}
6:null
