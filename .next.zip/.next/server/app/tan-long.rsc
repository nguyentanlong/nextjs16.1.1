1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/2e59f4238886288d.js"],"AuthProvider"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/2e59f4238886288d.js"],""]
10:I[68027,[],"default"]
:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
5:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      8:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"P":null,"b":"a-I7JEY3JjJc78c4aaeM5","c":["","tan-long"],"q":"","i":false,"f":[[["",{"children":["(main)",{"children":["tan-long",{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/dee56bed382e44f7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2e59f4238886288d.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{"children":"$undefined"}],["$","body",null,{"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$5"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L6",null,{"src":"./script-alt.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"./product-script.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"/script-login.js","strategy":"lazyOnload"}]]}]]}]]}],{"children":[["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3c46c67f24ea5105.js","async":true,"nonce":"$undefined"}]],["$L7",["$","main",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$8"}],"$L9","$La","$Lb"],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],"$Lc"]]}],{"children":["$Ld",{"children":["$Le",{},null,false,false]},null,false,false]},null,false,false]},null,false,false],"$Lf",false]],"m":"$undefined","G":["$10",[]],"S":true}
11:I[22016,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],""]
13:I[5500,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js","/_next/static/chunks/a8722805a7e8d032.js"],"Image"]
14:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
15:"$Sreact.suspense"
17:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ViewportBoundary"]
19:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"MetadataBoundary"]
9:["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}]
a:["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}]
b:["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]
c:["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"container footer-container","children":[["$","div",null,{"className":"footer-col logo-col","children":[["$","h2",null,{"className":"footer-logo","children":["MANH ",["$","span",null,{"children":"PHÁT"}]]}],["$","p",null,{"className":"footer-desc","children":"Manh Phát được thành lập với mong muốn tạo ra một môi trường làm việc chuyên nghiệp, và cung cấp giải pháp tối ưu trong lĩnh vực camera giám sát, năng lượng mặt trời, và điện cơ."}],["$","div",null,{"className":"footer-contact","children":[["$","p",null,{"children":[["$","span",null,{"children":"Location"}]," 145, DT741, Phường Phước Bình, Đồng Nai"]}],["$","p",null,{"children":[["$","span",null,{"children":"Phone"}]," 0328.76.2676"]}],["$","p",null,{"children":[["$","span",null,{"children":"Email"}]," hitlong.dinho.89@gmail.com"]}]]}]]}],["$","div",null,{"className":"footer-col map-col","children":[["$","h3",null,{"children":"CHỈ ĐƯỜNG"}],["$","div",null,{"className":"map-wrapper","children":["$","iframe",null,{"src":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.610934259323!2d106.7894596148005!3d10.83445779228892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528e1e6396e13%3A0x74b745b6f0e1c8c!2sCTY%20TNHH%20C%C6%A0%20%C4%90I%E1%BB%86N%20MANH%20PH%C3%81T!5e0!3m2!1svi!2s!4v1710000000000","width":"100%","height":300,"style":{"border":0},"loading":"lazy"}]}]]}],["$","div",null,{"className":"footer-col social-col","children":[["$","h3",null,{"children":"LIÊN KẾT"}],["$","ul",null,{"className":"social-links","children":[["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Facebook kỹ thuật"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Facebook kinh doanh"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Zalo kỹ thuật"}]}],["$","li",null,{"children":["$","$L11",null,{"href":"tel:+84328732676","children":"Zalo kinh doanh"}]}]]}]]}]]}],["$","div",null,{"className":"footer-bottom","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2026 Tấn Long. Đã đăng ký bản quyền. Design with Tấn Long & Cà Phê"}]}]}]]}]
d:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
12:T5b7,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
          img{width: 100%}
      e:["$","$1","c",{"children":[[["$","style",null,{"children":"$12"}],["$","header",null,{"children":[["$","h1",null,{"children":"Nguyên Tấn Long"}],["$","p",null,{"children":"Sinh ngày 09/09/1989"}]]}],["$","section",null,{"children":[["$","h2",null,{"children":"Về Tôi"}],["$","p",null,{"children":["Tôi là ",["$","span",null,{"className":"highlight","children":"Nguyên Tấn Long"}],", sinh ngày 09/09/1989. Với niềm đam mê học hỏi và khát vọng phát triển, tôi luôn hướng đến việc tạo ra giá trị bền vững cho cộng đồng và xã hội."]}],["$","$L13",null,{"src":"/public/ANH-DD.webp","alt":"Nguyen-Tan-Long","width":578,"height":600}],["$","p",null,{"children":"Trang web này được xây dựng nhằm chia sẻ hành trình, kinh nghiệm và những dự án mà tôi đã và đang thực hiện. Tôi tin rằng mỗi bước đi đều mang lại bài học quý giá, và tôi muốn lan tỏa tinh thần tích cực đó đến mọi người."}],["$","p",null,{"children":"Nếu bạn quan tâm, hãy kết nối để cùng nhau hợp tác và phát triển."}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[["$","script","script-0",{"src":"/_next/static/chunks/a8722805a7e8d032.js","async":true,"nonce":"$undefined"}]],["$","$L14",null,{"children":["$","$15",null,{"name":"Next.MetadataOutlet","children":"$@16"}]}]]}]
f:["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","div",null,{"hidden":true,"children":["$","$L19",null,{"children":["$","$15",null,{"name":"Next.Metadata","children":"$L1a"}]}]}],null]}]
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"IconMark"]
16:null
1a:[["$","title","0",{"children":"Camera giám sát - năng lượng mặt trời"}],["$","meta","1",{"name":"description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","2",{"name":"keywords","content":"camera giám sát,năng lượng mặt trời,thi công điện nước,pccc,camera giam sat,nang luong mat troi,thi cong dien nuoc,thiết bị pccc,thiet bi pccc,bình chữa cháy,binh chua chay,bảo hộ lao động,bao ho lao dong"}],["$","link","3",{"rel":"canonical","href":"https://tanlong.work.gd"}],["$","meta","4",{"property":"og:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","5",{"property":"og:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","6",{"property":"og:url","content":"https://tanlong.work.gd"}],["$","meta","7",{"property":"og:site_name","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","8",{"property":"og:locale","content":"vi_VN"}],["$","meta","9",{"property":"og:country_name","content":"Việt Nam"}],["$","meta","10",{"property":"og:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],["$","meta","12",{"property":"og:image:height","content":"630"}],["$","meta","13",{"property":"og:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","14",{"property":"og:email","content":"hitlong.dinho.89@gmail.com"}],["$","meta","15",{"property":"og:phone_number","content":"0328732676"}],["$","meta","16",{"property":"og:type","content":"website"}],["$","meta","17",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","18",{"name":"twitter:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","19",{"name":"twitter:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","20",{"name":"twitter:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","21",{"name":"twitter:image:width","content":"800"}],["$","meta","22",{"name":"twitter:image:height","content":"630"}],["$","meta","23",{"name":"twitter:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","link","24",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","25",{"rel":"icon","href":"/favicon.ico?favicon.b838974e.ico","sizes":"32x31","type":"image/x-icon"}],["$","link","26",{"rel":"icon","href":"/logo-manh-phat-van-ban.png"}],["$","link","27",{"rel":"apple-touch-icon","href":"/favicon.ico"}],["$","$L1b","28",{}]]
1c:I[88589,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
7:[["$","div",null,{"className":"topbar","children":["$","div",null,{"className":"topbar-container","children":[["$","div",null,{"className":"topbar-left","children":[["$","div",null,{"className":"dropdown","id":"lang-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tiếng Việt ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L11",null,{"href":"#","children":"Tiếng Việt"}],["$","$L11",null,{"href":"#","children":"English"}]]}]]}],["$","div",null,{"className":"dropdown","id":"account-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tài khoản của bạn ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L11",null,{"href":"/login","children":"Đăng nhập"}],["$","hr",null,{}],["$","$L11",null,{"href":"/register","children":"Đăng ký miễn phí"}],["$","hr",null,{}]]}]]}]]}],["$","div",null,{"className":"topbar-right","children":[["$","$L11",null,{"href":"/product-detail","className":"highlight","children":"Mã giảm giá"}],["$","$L11",null,{"href":"/guide","children":"Hướng dẫn"}],["$","a",null,{"href":"tel:0328732676","className":"hotline","children":"Hotline: 0328.73.2676"}]]}]]}]}],["$","header",null,{"className":"main-header","children":["$","div",null,{"className":"container","children":[["$","$L11",null,{"href":"/","className":"logo","children":["$","img",null,{"src":"https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","alt":"Muamau","height":44}]}],["$","$L1c",null,{"subCategories":[{"id":1,"categoryName":"Ip","slugSub":"nguyen-tan-long-1.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":2,"categoryName":"Thân","slugSub":"nguyen-tan-long-2.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":3,"categoryName":"Quấn motor","slugSub":"nguyen-tan-long-3.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":4,"categoryName":"Thiết kế Website","slugSub":"nguyen-tan-long-4.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":5,"categoryName":"Thi công PCCC","slugSub":"nguyen-tan-long-5.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":6,"categoryName":"Điện dân dụng","slugSub":"nguyen-tan-long-6.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":7,"categoryName":"Xưởng & đất lớn","slugSub":"nguyen-tan-long-7.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":8,"categoryName":"Nhà dân & đất nền","slugSub":"nguyen-tan-long-8.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":11,"categoryName":"Thiết kế phần mềm","slugSub":"nguyen-tan-long-9.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":12,"categoryName":"Đất dự án","slugSub":"nguyen-tan-long-10.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":13,"categoryName":"Sữa chữa camera","slugSub":"nguyen-tan-long-11.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":14,"categoryName":"Sữa chũa laptop pc","slugSub":"nguyen-tan-long-12.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":15,"categoryName":"Nạp bình chữa cháy","slugSub":"nguyen-tan-long-13.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":16,"categoryName":"Bình chữa cháy bột","slugSub":"nguyen-tan-long-14.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":17,"categoryName":"Bình chữa cháy khí","slugSub":"nguyen-tan-long-15.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":18,"categoryName":"Bình chữa cháy gốc nước","slugSub":"nguyen-tan-long-16.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"},{"id":19,"categoryName":"Vật tư PCCC","slugSub":"nguyen-tan-long-17.html","image":"/uploads/subcategories/file-nguyen-tan-long-1773219017961.webp"},{"id":20,"categoryName":"SP Mạnh Phát","slugSub":"nguyen-tan-long-18.html","image":"/uploads/subcategories/xuong-thue-nguyen-tan-long-1773219281651.jpg"}]}],"$L1d"]}]}]]
1e:I[5903,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/3c46c67f24ea5105.js"],"default"]
1d:["$","$L1e",null,{}]
