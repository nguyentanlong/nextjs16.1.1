1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ClientSegmentRoot"]
3:I[35052,["/_next/static/chunks/d01fb2d5fb7718e4.js","/_next/static/chunks/c5fbe453c33ce41e.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
:HL["/_next/static/chunks/57834efd96369ecc.css","style"]
0:{"buildId":"IB0L2m1cykyh4u1kUrVtw","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/57834efd96369ecc.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/c5fbe453c33ce41e.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:{}
