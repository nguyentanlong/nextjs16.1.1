:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
:HL["/_next/static/chunks/57834efd96369ecc.css","style"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"login","paramType":null,"paramKey":"login","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
