1:"$Sreact.fragment"
2:I[62873,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],"default"]
3:I[60723,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],""]
:HL["/_next/static/chunks/9be2b84d16a06f7e.css","style"]
:HL["/_next/static/chunks/75d98ddf282c645b.css","style"]
:HL["/_next/static/chunks/1f99761cb8153339.css","style"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/9be2b84d16a06f7e.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/75d98ddf282c645b.css","precedence":"next"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/chunks/1f99761cb8153339.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0fdbf14afde6e414.js","async":true}]],[["$","div",null,{"className":"g-sidenav-show bg-gray-100","style":{"minHeight":"100vh"},"children":[["$","$L2",null,{}],["$","div",null,{"className":"main-content position-relative h-100 border-radius-lg","style":{"minHeight":"100vh"},"children":[["$","$L3",null,{}],["$","main",null,{"className":"container-fluid py-4","children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]}]]}]]}],["$","$L6",null,{"src":"./material-dashdoard.min.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"./perfect-scrollbar.min.js","strategy":"lazyOnload"}]]]}],"loading":null,"isPartial":false}
