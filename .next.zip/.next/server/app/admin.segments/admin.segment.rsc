1:"$Sreact.fragment"
2:I[62873,["/_next/static/chunks/d01fb2d5fb7718e4.js","/_next/static/chunks/26b033aaea618c85.js"],"default"]
3:I[60723,["/_next/static/chunks/d01fb2d5fb7718e4.js","/_next/static/chunks/26b033aaea618c85.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/d01fb2d5fb7718e4.js","/_next/static/chunks/26b033aaea618c85.js"],""]
:HL["/_next/static/chunks/9be2b84d16a06f7e.css","style"]
:HL["/_next/static/chunks/085ac1e1350d1d3c.css","style"]
:HL["/_next/static/chunks/1f99761cb8153339.css","style"]
0:{"buildId":"IB0L2m1cykyh4u1kUrVtw","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/9be2b84d16a06f7e.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/085ac1e1350d1d3c.css","precedence":"next"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/chunks/1f99761cb8153339.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/26b033aaea618c85.js","async":true}]],[["$","div",null,{"className":"g-sidenav-show  bg-gray-100","children":[["$","$L2",null,{}],["$","$L3",null,{}],["$","main",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]}]]}],["$","$L6",null,{"src":"./material-dashdoard.min.js"}],["$","$L6",null,{"src":"./perfect-scrollbar.min.js"}]]]}],"loading":null,"isPartial":false}
