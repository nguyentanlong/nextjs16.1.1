1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/2e59f4238886288d.js"],"AuthProvider"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],""]
:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
5:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/dee56bed382e44f7.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2e59f4238886288d.js","async":true}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{}],["$","body",null,{"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[[["$","style",null,{"children":"$5"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]]}]}],["$","$L6",null,{"src":"./script-alt.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"./product-script.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"/script-login.js","strategy":"lazyOnload"}]]}]]}]]}],"loading":null,"isPartial":false}
