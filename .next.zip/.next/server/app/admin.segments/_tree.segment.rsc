:HL["/_next/static/chunks/2cb20408bc896f7e.css","style"]
:HL["/_next/static/chunks/9be2b84d16a06f7e.css","style"]
:HL["/_next/static/chunks/085ac1e1350d1d3c.css","style"]
:HL["/_next/static/chunks/1f99761cb8153339.css","style"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
0:{"buildId":"IB0L2m1cykyh4u1kUrVtw","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"admin","paramType":null,"paramKey":"admin","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
