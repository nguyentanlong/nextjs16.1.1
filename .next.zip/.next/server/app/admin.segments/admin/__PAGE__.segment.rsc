1:"$Sreact.fragment"
2:I[64750,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js","/_next/static/chunks/12d27f3167e5e173.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/12d27f3167e5e173.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
