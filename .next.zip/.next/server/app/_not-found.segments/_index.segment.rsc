1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"AuthProvider"]
3:I[22016,["/_next/static/chunks/d01fb2d5fb7718e4.js"],""]
4:I[88589,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"default"]
5:I[5903,["/_next/static/chunks/d01fb2d5fb7718e4.js"],"default"]
6:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
7:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
10:I[79520,["/_next/static/chunks/d01fb2d5fb7718e4.js"],""]
:HL["/_next/static/chunks/2cb20408bc896f7e.css","style"]
:HL["https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","image"]
8:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"buildId":"IB0L2m1cykyh4u1kUrVtw","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2cb20408bc896f7e.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/d01fb2d5fb7718e4.js","async":true}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{}],["$","body",null,{"children":[["$","$L2",null,{"children":[[["$","div",null,{"className":"topbar","children":["$","div",null,{"className":"topbar-container","children":[["$","div",null,{"className":"topbar-left","children":[["$","div",null,{"className":"dropdown","id":"lang-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tiếng Việt ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L3",null,{"href":"#","children":"Tiếng Việt"}],["$","$L3",null,{"href":"#","children":"English"}]]}]]}],["$","div",null,{"className":"dropdown","id":"account-dropdown","children":[["$","button",null,{"className":"dropbtn","children":["Tài khoản của bạn ",["$","span",null,{"className":"arrow","children":"v"}]]}],["$","div",null,{"className":"dropdown-menu","children":[["$","$L3",null,{"href":"/login","children":"Đăng nhập"}],["$","hr",null,{}],["$","$L3",null,{"href":"/register","children":"Đăng ký miễn phí"}],["$","hr",null,{}]]}]]}]]}],["$","div",null,{"className":"topbar-right","children":[["$","$L3",null,{"href":"/product-detail","className":"highlight","children":"Mã giảm giá"}],["$","$L3",null,{"href":"/guide","children":"Hướng dẫn"}],["$","a",null,{"href":"tel:0328732676","className":"hotline","children":"Hotline: 0328.73.2676"}]]}]]}]}],["$","header",null,{"className":"main-header","children":["$","div",null,{"className":"container","children":[["$","$L3",null,{"href":"/","className":"logo","children":["$","img",null,{"src":"https://pantravel.vn/wp-content/uploads/2024/07/cuc-quang-hien-tuong-dep-nhat-cua-tu-nhien-1536x864.jpg","alt":"Muamau","height":44}]}],["$","$L4",null,{"subCategories":[]}],["$","$L5",null,{}]]}]}]],["$","main",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","template":["$","$L7",null,{}],"notFound":[[["$","style",null,{"children":"$8"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],"$L9"]}],"$La"],[]]}]}],"$Lb"]}],"$Lc","$Ld","$Le","$Lf"]}]]}]]}],"loading":null,"isPartial":false}
9:["$","h4",null,{"children":"Kết nối ngay"}]
a:["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]
b:["$","footer",null,{"className":"site-footer","children":[["$","div",null,{"className":"container footer-container","children":[["$","div",null,{"className":"footer-col logo-col","children":[["$","h2",null,{"className":"footer-logo","children":["MANH ",["$","span",null,{"children":"PHÁT"}]]}],["$","p",null,{"className":"footer-desc","children":"Manh Phát được thành lập với mong muốn tạo ra một môi trường làm việc chuyên nghiệp, và cung cấp giải pháp tối ưu trong lĩnh vực camera giám sát, năng lượng mặt trời, và điện cơ."}],["$","div",null,{"className":"footer-contact","children":[["$","p",null,{"children":[["$","span",null,{"children":"Location"}]," 51, ĐT744, kp Phú Thọ, p Phú An, HCM"]}],["$","p",null,{"children":[["$","span",null,{"children":"Phone"}]," Phone: 0934 181 151"]}],["$","p",null,{"children":[["$","span",null,{"children":"Email"}]," congtytnhcodienmanhphat@gmail.com"]}]]}]]}],["$","div",null,{"className":"footer-col map-col","children":[["$","h3",null,{"children":"CHỈ ĐƯỜNG"}],["$","div",null,{"className":"map-wrapper","children":["$","iframe",null,{"src":"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.610934259323!2d106.7894596148005!3d10.83445779228892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528e1e6396e13%3A0x74b745b6f0e1c8c!2sCTY%20TNHH%20C%C6%A0%20%C4%90I%E1%BB%86N%20MANH%20PH%C3%81T!5e0!3m2!1svi!2s!4v1710000000000","width":"100%","height":300,"style":{"border":0},"loading":"lazy"}]}]]}],["$","div",null,{"className":"footer-col social-col","children":[["$","h3",null,{"children":"LIÊN KẾT"}],["$","ul",null,{"className":"social-links","children":[["$","li",null,{"children":["$","a",null,{"href":"#","children":"Facebook kỹ thuật"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Facebook kinh doanh"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Zalo kỹ thuật"}]}],["$","li",null,{"children":["$","a",null,{"href":"#","children":"Zalo kinh doanh"}]}]]}]]}]]}],["$","div",null,{"className":"footer-bottom","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2025 Manh Phát. Đã đăng ký bản quyền. Design with Love by Đệ tử & Sư phụ"}]}]}]]}]
c:["$","$L10",null,{"src":"/script.js","strategy":"afterInteractive"}]
d:["$","$L10",null,{"src":"./script-alt.js","strategy":"afterInteractive"}]
e:["$","$L10",null,{"src":"./product-script.js","strategy":"afterInteractive"}]
f:["$","$L10",null,{"src":"/script-login.js","strategy":"afterInteractive"}]
