1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
3:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
4:I[79520,["/_next/static/chunks/2e59f4238886288d.js"],""]
:HL["/_next/static/chunks/af6e869b1021068d.css","style"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/af6e869b1021068d.css","precedence":"next"}]],["$","main",null,{"children":[["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}],["$","$L4",null,{"src":"./script-register.js","strategy":"lazyOnload"}],["$","$L4",null,{"src":"./script-alt.js","strategy":"lazyOnload"}]]}]]}],"loading":null,"isPartial":false}
