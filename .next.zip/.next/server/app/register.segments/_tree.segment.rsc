:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
:HL["/_next/static/chunks/af6e869b1021068d.css","style"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"register","paramType":null,"paramKey":"register","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
