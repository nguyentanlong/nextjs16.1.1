1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"g-sidenav-show  bg-gray-100","children":["$","h1",null,{"children":"Quản Tri"}]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
