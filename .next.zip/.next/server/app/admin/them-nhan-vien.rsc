1:"$Sreact.fragment"
2:I[32341,["/_next/static/chunks/2e59f4238886288d.js"],"AuthProvider"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"default"]
6:I[79520,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],""]
7:I[62873,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],"default"]
8:I[60723,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js"],"default"]
f:I[68027,[],"default"]
:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
:HL["/_next/static/chunks/9be2b84d16a06f7e.css","style"]
:HL["/_next/static/chunks/75d98ddf282c645b.css","style"]
:HL["/_next/static/chunks/1f99761cb8153339.css","style"]
5:T59c,
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      0:{"P":null,"b":"a-I7JEY3JjJc78c4aaeM5","c":["","admin","them-nhan-vien"],"q":"","i":false,"f":[[["",{"children":["admin",{"children":["them-nhan-vien",{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/dee56bed382e44f7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2e59f4238886288d.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"vi","children":[["$","head",null,{"children":"$undefined"}],["$","body",null,{"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","style",null,{"children":"$5"}],["$","header",null,{"children":["$","p",null,{"children":"Trang này không tồn tại, hoặc bị xóa"}]}],["$","section",null,{"children":[["$","h2",null,{"children":"Nguyễn Tan Long"}],["$","p",null,{"children":["Xin lỗi về ",["$","span",null,{"className":"highlight","children":"sự bất tiện này"}],", tôi sẽ khắc phục sớm nhất có thể."]}],["$","p",null,{"children":"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}],["$","p",null,{"children":"Biết ơn vì bạn đã quan tâm đến website!"}],["$","h4",null,{"children":"Kết nối ngay"}]]}],["$","footer",null,{"children":["$","p",null,{"children":"© 2026 Nguyên Tấn Long - All Rights Reserved"}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L6",null,{"src":"./script-alt.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"./product-script.js","strategy":"lazyOnload"}],["$","$L6",null,{"src":"/script-login.js","strategy":"lazyOnload"}]]}]]}]]}],{"children":[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/9be2b84d16a06f7e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/75d98ddf282c645b.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/chunks/1f99761cb8153339.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0fdbf14afde6e414.js","async":true,"nonce":"$undefined"}]],[["$","div",null,{"className":"g-sidenav-show bg-gray-100","style":{"minHeight":"100vh"},"children":[["$","$L7",null,{}],["$","div",null,{"className":"main-content position-relative h-100 border-radius-lg","style":{"minHeight":"100vh"},"children":[["$","$L8",null,{}],["$","main",null,{"className":"container-fluid py-4","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":"$L9","templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]]}],"$La","$Lb"]]}],{"children":["$Lc",{"children":["$Ld",{},null,false,false]},null,false,false]},null,false,false]},null,false,false],"$Le",false]],"m":"$undefined","G":["$f",[]],"S":true}
10:I[47257,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ClientPageRoot"]
11:I[87431,["/_next/static/chunks/2e59f4238886288d.js","/_next/static/chunks/0fdbf14afde6e414.js","/_next/static/chunks/07ef3de17e3a8bb9.js"],"default"]
14:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"OutletBoundary"]
15:"$Sreact.suspense"
17:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"ViewportBoundary"]
19:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"MetadataBoundary"]
9:["$","$L4",null,{}]
a:["$","$L6",null,{"src":"./material-dashdoard.min.js","strategy":"lazyOnload"}]
b:["$","$L6",null,{"src":"./perfect-scrollbar.min.js","strategy":"lazyOnload"}]
c:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
d:["$","$1","c",{"children":[["$","$L10",null,{"Component":"$11","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@12","$@13"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/07ef3de17e3a8bb9.js","async":true,"nonce":"$undefined"}]],["$","$L14",null,{"children":["$","$15",null,{"name":"Next.MetadataOutlet","children":"$@16"}]}]]}]
e:["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","div",null,{"hidden":true,"children":["$","$L19",null,{"children":["$","$15",null,{"name":"Next.Metadata","children":"$L1a"}]}]}],null]}]
12:{}
13:"$d:props:children:0:props:serverProvidedParams:params"
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7340adf74ff47ec0.js"],"IconMark"]
16:null
1a:[["$","title","0",{"children":"Camera giám sát - năng lượng mặt trời"}],["$","meta","1",{"name":"description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","2",{"name":"keywords","content":"camera giám sát,năng lượng mặt trời,thi công điện nước,pccc,camera giam sat,nang luong mat troi,thi cong dien nuoc,thiết bị pccc,thiet bi pccc,bình chữa cháy,binh chua chay,bảo hộ lao động,bao ho lao dong"}],["$","link","3",{"rel":"canonical","href":"https://tanlong.work.gd"}],["$","meta","4",{"property":"og:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","5",{"property":"og:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","6",{"property":"og:url","content":"https://tanlong.work.gd"}],["$","meta","7",{"property":"og:site_name","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","8",{"property":"og:locale","content":"vi_VN"}],["$","meta","9",{"property":"og:country_name","content":"Việt Nam"}],["$","meta","10",{"property":"og:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],["$","meta","12",{"property":"og:image:height","content":"630"}],["$","meta","13",{"property":"og:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","14",{"property":"og:email","content":"hitlong.dinho.89@gmail.com"}],["$","meta","15",{"property":"og:phone_number","content":"0328732676"}],["$","meta","16",{"property":"og:type","content":"website"}],["$","meta","17",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","18",{"name":"twitter:title","content":"Camera giám sát - năng lượng mặt trời"}],["$","meta","19",{"name":"twitter:description","content":"Thi công điện dân dụng, công nghiệp, camera giám sát, năng lượng mặt trời, pccc, blhd, cơ điện tại HCM, Bình Dương, \n  Bình Phước, Đồng Nai, Tây Ninh, Vũng Tàu, DakNong, DakLak, toàn quốc. Nghiệm thu từng giai đoạn, chuyên\n  nghiệp"}],["$","meta","20",{"name":"twitter:image","content":"https://tanong.work.gd/logo-manh-phat-van-ban.png"}],["$","meta","21",{"name":"twitter:image:width","content":"800"}],["$","meta","22",{"name":"twitter:image:height","content":"630"}],["$","meta","23",{"name":"twitter:image:alt","content":"Camera giám sát - năng lượng mặt trời"}],["$","link","24",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","25",{"rel":"icon","href":"/favicon.ico?favicon.b838974e.ico","sizes":"32x31","type":"image/x-icon"}],["$","link","26",{"rel":"icon","href":"/logo-manh-phat-van-ban.png"}],["$","link","27",{"rel":"apple-touch-icon","href":"/favicon.ico"}],["$","$L1b","28",{}]]
