:HL["/_next/static/chunks/dee56bed382e44f7.css","style"]
:HL["/_next/static/chunks/9be2b84d16a06f7e.css","style"]
:HL["/_next/static/chunks/75d98ddf282c645b.css","style"]
:HL["/_next/static/chunks/1f99761cb8153339.css","style"]
0:{"buildId":"a-I7JEY3JjJc78c4aaeM5","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"admin","paramType":null,"paramKey":"admin","hasRuntimePrefetch":false,"slots":{"children":{"name":"profile","paramType":null,"paramKey":"profile","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
