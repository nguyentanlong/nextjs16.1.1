globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7a0a31b0bb154d05.js",
    "static/chunks/c0bc13f8166cc48f.js",
    "static/chunks/3e200bca904262de.js",
    "static/chunks/c5802cb792f53f74.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-6b4054c6c242d4e8.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];