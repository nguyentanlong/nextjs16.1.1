globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/dfaf1a48efd128f5.js",
    "static/chunks/5cedbe3d28acc407.js",
    "static/chunks/ed432eccdaca5a7e.js",
    "static/chunks/c5802cb792f53f74.js",
    "static/chunks/turbopack-76f162e4cc906d25.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];