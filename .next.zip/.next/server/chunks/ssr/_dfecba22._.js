module.exports=[47283,(a,b,c)=>{b.exports=a.r(96665)},24066,a=>{"use strict";var b=a.i(87924),c=a.i(47283);function d({children:a}){return(0,b.jsxs)(b.Fragment,{children:[a,(0,b.jsx)(c.default,{src:"./script-login.js",strategy:"lazyOnload"}),(0,b.jsx)(c.default,{src:"./script-alt.js",strategy:"lazyOnload"})]})}a.s(["default",()=>d])}];

//# sourceMappingURL=_dfecba22._.js.map