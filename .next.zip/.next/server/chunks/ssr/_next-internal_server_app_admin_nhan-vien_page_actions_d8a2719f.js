module.exports=[38158,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_nhan-vien_page_actions_d8a2719f.js.map