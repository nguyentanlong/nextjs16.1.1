module.exports=[30114,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("h1",{children:"SanPham Page"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_admin_san-pham_page_tsx_50f2b07e._.js.map