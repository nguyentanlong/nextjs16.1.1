module.exports=[6617,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_them-nhan-vien_page_actions_120b31cf.js.map