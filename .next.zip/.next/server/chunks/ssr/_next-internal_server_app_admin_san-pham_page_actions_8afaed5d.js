module.exports=[57690,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_san-pham_page_actions_8afaed5d.js.map