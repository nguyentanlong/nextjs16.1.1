module.exports=[40222,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("h1",{children:"Profile Page"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_admin_profile_page_tsx_4bf1932a._.js.map