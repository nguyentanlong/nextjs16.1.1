module.exports=[3363,a=>{"use strict";var b=a.i(7997);function c(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: #f9f9f9;
          color: #333;
        }
        header {
          background: linear-gradient(90deg, #0066cc, #0099ff);
          color: white;
          text-align: center;
          padding: 40px 20px;
        }
        header h1 {
          margin: 0;
          font-size: 2.5em;
        }
        header p {
          margin: 10px 0 0;
          font-size: 1.2em;
        }
        section {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        section h2 {
          color: #0066cc;
          margin-bottom: 20px;
        }
        section p {
          line-height: 1.6;
          margin-bottom: 15px;
        }
        footer {
          text-align: center;
          padding: 20px;
          background: #0066cc;
          color: white;
          margin-top: 40px;
        }
        .highlight {
          font-weight: bold;
          color: #0099ff;
        }
        button {
          background: #0099ff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover {
          background: #0066cc;
        }
      `}),(0,b.jsx)("header",{children:(0,b.jsx)("p",{children:"Trang này không tồn tại, hoặc bị xóa"})}),(0,b.jsxs)("section",{children:[(0,b.jsx)("h2",{children:"Nguyễn Tan Long"}),(0,b.jsxs)("p",{children:["Xin lỗi về ",(0,b.jsx)("span",{className:"highlight",children:"sự bất tiện này"}),", tôi sẽ khắc phục sớm nhất có thể."]}),(0,b.jsx)("p",{children:"Bạn hãy click trở về trang chủ để tiếp tục, hoặc liên hệ trực tiếp với ADMIN để phản ánh nhé"}),(0,b.jsx)("p",{children:"Biết ơn vì bạn đã quan tâm đến website!"}),(0,b.jsx)("h4",{children:"Kết nối ngay"})]}),(0,b.jsx)("footer",{children:(0,b.jsx)("p",{children:"© 2026 Nguyên Tấn Long - All Rights Reserved"})})]})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_not-found_tsx_3f23d179._.js.map