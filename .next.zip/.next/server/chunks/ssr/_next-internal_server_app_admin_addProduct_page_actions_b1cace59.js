module.exports=[24932,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_addProduct_page_actions_b1cace59.js.map