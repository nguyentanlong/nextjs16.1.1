module.exports=[16697,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_san-pham_page_actions_038615b6.js.map