module.exports=[30324,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tat-ca-san-pham_page_actions_f9ea904f.js.map