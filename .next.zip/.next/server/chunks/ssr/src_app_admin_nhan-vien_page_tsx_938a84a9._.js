module.exports=[13344,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("h1",{children:"NhanVien Page"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_admin_nhan-vien_page_tsx_938a84a9._.js.map