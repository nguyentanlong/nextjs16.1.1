module.exports=[20436,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("h1",{children:"Likes Page"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_admin_likes_page_tsx_25af1602._.js.map