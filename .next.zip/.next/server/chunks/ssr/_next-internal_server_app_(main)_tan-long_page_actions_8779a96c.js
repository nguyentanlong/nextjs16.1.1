module.exports=[19755,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_tan-long_page_actions_8779a96c.js.map