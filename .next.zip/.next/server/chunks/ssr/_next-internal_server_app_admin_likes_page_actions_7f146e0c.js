module.exports=[49874,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_likes_page_actions_7f146e0c.js.map