module.exports=[85221,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tan-long_page_actions_0c08759d.js.map