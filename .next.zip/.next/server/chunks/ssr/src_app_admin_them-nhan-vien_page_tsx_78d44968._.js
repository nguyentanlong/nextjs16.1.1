module.exports=[73047,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("h1",{children:"Nhanvien Page"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_admin_them-nhan-vien_page_tsx_78d44968._.js.map